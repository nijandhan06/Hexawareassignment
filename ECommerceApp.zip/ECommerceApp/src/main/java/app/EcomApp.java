package app;

import dao.OrderProcessorRepository;
import dao.OrderProcessorRepositoryImpl;
import entity.Customer;
import entity.Product;
import exception.ProductNotFoundException;

import java.util.*;

public class EcomApp {
    private static OrderProcessorRepository orderProcessor = new OrderProcessorRepositoryImpl();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;
        
        while (running) {
            System.out.println("\n===== E-Commerce System Menu =====");
            System.out.println("1. Register Customer");
            System.out.println("2. Create Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Add to Cart");
            System.out.println("5. View Cart");
            System.out.println("6. Place Order");
            System.out.println("7. View Customer Orders");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            
            try {
                switch (choice) {
                    case 1:
                        registerCustomer();
                        break;
                    case 2:
                        createProduct();
                        break;
                    case 3:
                        deleteProduct();
                        break;
                    case 4:
                        addToCart();
                        break;
                    case 5:
                        viewCart();
                        break;
                    case 6:
                        placeOrder();
                        break;
                    case 7:
                        viewCustomerOrders();
                        break;
                    case 8:
                        running = false;
                        System.out.println("Exiting the system. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (ProductNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        scanner.close();
    }

    private static void registerCustomer() {
        System.out.println("\n--- Register Customer ---");
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        Customer customer = new Customer(0, name, email, password);
        boolean success = orderProcessor.createCustomer(customer);
        
        if (success) {
            System.out.println("Customer registered successfully with ID: " + customer.getCustomerId());
        } else {
            System.out.println("Failed to register customer.");
        }
    }

    private static void createProduct() {
        System.out.println("\n--- Create Product ---");
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); 
        
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        
        System.out.print("Enter stock quantity: ");
        int stockQuantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        Product product = new Product(0, name, price, description, stockQuantity);
        boolean success = orderProcessor.createProduct(product);
        
        if (success) {
            System.out.println("Product created successfully with ID: " + product.getProductId());
        } else {
            System.out.println("Failed to create product.");
        }
    }

    private static void deleteProduct() throws ProductNotFoundException, Exception {
        System.out.println("\n--- Delete Product ---");
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); 
        
        boolean success = orderProcessor.deleteProduct(productId);
        
        if (success) {
            System.out.println("Product deleted successfully.");
        } else {
            System.out.println("Failed to delete product.");
        }
    }

    private static void addToCart() {
        System.out.println("\n--- Add to Cart ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); 
        
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); 
        
        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        
        Product product = new Product();
        product.setProductId(productId);
        
        boolean success = orderProcessor.addToCart(customer, product, quantity);
        
        if (success) {
            System.out.println("Product added to cart successfully.");
        } else {
            System.out.println("Failed to add product to cart.");
        }
    }

    private static void viewCart() {
        System.out.println("\n--- View Cart ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        
        List<Product> cartProducts = orderProcessor.getAllFromCart(customer);
        
        if (cartProducts.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            System.out.println("Products in your cart:");
            for (Product product : cartProducts) {
                System.out.println("ID: " + product.getProductId() + 
                                 ", Name: " + product.getName() + 
                                 ", Price: " + product.getPrice());
            }
        }
    }

    private static void placeOrder() {
        System.out.println("\n--- Place Order ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        
        // Get products from cart
        List<Product> cartProducts = orderProcessor.getAllFromCart(customer);
        
        if (cartProducts.isEmpty()) {
            System.out.println("Your cart is empty. Cannot place order.");
            return;
        }
        

        List<Map<Product, Integer>> productsWithQuantities = new ArrayList<>();
   
        for (Product product : cartProducts) {
            Map<Product, Integer> item = new HashMap<>();
            item.put(product, 1); // Default quantity to 1 for this example
            productsWithQuantities.add(item);
        }
        
        System.out.print("Enter shipping address: ");
        String shippingAddress = scanner.nextLine();
        
        boolean success = orderProcessor.placeOrder(customer, productsWithQuantities, shippingAddress);
        
        if (success) {
            System.out.println("Order placed successfully.");
        } else {
            System.out.println("Failed to place order.");
        }
    }

    private static void viewCustomerOrders() {
        System.out.println("\n--- View Customer Orders ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        List<Map<Product, Integer>> orders = orderProcessor.getOrdersByCustomer(customerId);
        
        if (orders.isEmpty()) {
            System.out.println("No orders found for this customer.");
        } else {
            System.out.println("Orders for customer ID " + customerId + ":");
            int orderNumber = 1;
            for (Map<Product, Integer> order : orders) {
                System.out.println("\nOrder #" + orderNumber++);
                double orderTotal = 0;
                for (Map.Entry<Product, Integer> entry : order.entrySet()) {
                    Product product = entry.getKey();
                    int quantity = entry.getValue();
                    double itemTotal = product.getPrice() * quantity;
                    orderTotal += itemTotal;
                    
                    System.out.println("Product: " + product.getName() + 
                                     ", Quantity: " + quantity + 
                                     ", Price: " + product.getPrice() + 
                                     ", Total: " + itemTotal);
                }
                System.out.println("Order Total: " + orderTotal);
            }
        }
    }
}
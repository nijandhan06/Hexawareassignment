package dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.*;
import org.junit.*;
import entity.Customer;
import entity.Product;
import exception.CustomerNotFoundException;
import exception.ProductNotFoundException;

public class OrderProcessorRepositoryTest {
    private static OrderProcessorRepository orderProcessor;
    private static Customer testCustomer;
    private static Product testProduct;
    
    @BeforeClass
    public static void setUpBeforeClass() {
        orderProcessor = new OrderProcessorRepositoryImpl();
        
        // Create a test customer
        testCustomer = new Customer(0, "Ram Kumar", "ramkumar@gmail.com", "ramkumar123");
        orderProcessor.createCustomer(testCustomer);
        
        // Create a test product
        testProduct = new Product(0, "Orange", 18.78, "Orange is Orange in colour", 20);
        orderProcessor.createProduct(testProduct);
    }
    
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        // Clean up test data
        try {
            orderProcessor.deleteCustomer(testCustomer.getCustomerId());
        } catch (CustomerNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            orderProcessor.deleteProduct(testProduct.getProductId());
        } catch (ProductNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCreateProduct() throws Exception {
        Product product = new Product(0, "Bread", 9.99, "Wheat Bread", 50);
        boolean result = orderProcessor.createProduct(product);
        assertTrue("Product creation should succeed", result);
        assertTrue("Product ID should be greater than 0", product.getProductId() > 0);
        
        // Clean up
        try {
            orderProcessor.deleteProduct(product.getProductId());
        } catch (ProductNotFoundException e) {
            fail("Failed to clean up test product");
        }
    }
    
    @Test
    public void testCreateCustomer() throws Exception {
        Customer customer = new Customer(0, "Rahul", "rahult@gmail.com", "rahul123");
        boolean result = orderProcessor.createCustomer(customer);
        assertTrue("Customer creation should succeed", result);
        assertTrue("Customer ID should be greater than 0", customer.getCustomerId() > 0);
        
        // Clean up
        try {
            orderProcessor.deleteCustomer(customer.getCustomerId());
        } catch (CustomerNotFoundException e) {
            fail("Failed to clean up test customer");
        }
    }
    
    @Test
    public void testAddToCart() {
        boolean result = orderProcessor.addToCart(testCustomer, testProduct, 1);
        assertTrue("Add to cart should succeed", result);
        
        // Verify the cart contains the product
        List<Product> cartProducts = orderProcessor.getAllFromCart(testCustomer);
        assertFalse("Cart should not be empty", cartProducts.isEmpty());
        assertEquals("Cart should contain the test product", 
                    testProduct.getProductId(), cartProducts.get(0).getProductId());
        
        // Clean up
        orderProcessor.removeFromCart(testCustomer, testProduct);
    }
    
    @Test
    public void testPlaceOrder() {
        // Add product to cart first
        orderProcessor.addToCart(testCustomer, testProduct, 1);
        
        // Prepare order data
        List<Map<Product, Integer>> productsWithQuantities = new ArrayList<>();
        Map<Product, Integer> item = new HashMap<>();
        item.put(testProduct, 1);
        productsWithQuantities.add(item);
        
        // Place order
        boolean result = orderProcessor.placeOrder(testCustomer, productsWithQuantities, "Address");
        assertTrue("Place order should succeed", result);
        
        // Verify order exists
        List<Map<Product, Integer>> orders = orderProcessor.getOrdersByCustomer(testCustomer.getCustomerId());
        assertFalse("Customer should have orders", orders.isEmpty());
    }
    
    @Test(expected = ProductNotFoundException.class)
    public void testProductNotFoundException() throws ProductNotFoundException, Exception {
        orderProcessor.deleteProduct(-1); // Invalid product ID
    }
    
    @Test(expected = CustomerNotFoundException.class)
    public void testCustomerNotFoundException() throws CustomerNotFoundException, Exception {
        orderProcessor.deleteCustomer(-1); // Invalid customer ID
    }
}
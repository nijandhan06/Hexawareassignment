package main;

import entity.*;
import dao.*;
import exception.*;
import java.util.*;
import java.sql.*;

public class MainModule {
    private static Scanner scanner = new Scanner(System.in);
    private static IOrderManagementRepository orderProcessor = new OrderProcessor();
    
    public static void main(String[] args) {
        boolean running = true;
        
        while (running) {
            System.out.println("\nOrder Management System");
            System.out.println("1. Create User");
            System.out.println("2. Create Product (Admin only)");
            System.out.println("3. Create Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Get All Products");
            System.out.println("6. Get Orders by User");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            try {
                switch (choice) {
                    case 1:
                        createUser();
                        break;
                    case 2:
                        createProduct();
                        break;
                    case 3:
                        createOrder();
                        break;
                    case 4:
                        cancelOrder();
                        break;
                    case 5:
                        getAllProducts();
                        break;
                    case 6:
                        getOrdersByUser();
                        break;
                    case 7:
                        running = false;
                        System.out.println("Exiting system. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        
        scanner.close();
    }
    
    private static void createUser() {
        System.out.println("\n--- Create New User ---");
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        
        System.out.print("Enter Role (Admin/User): ");
        String role = scanner.nextLine();
        
        User user = new User(userId, username, password, role);
        orderProcessor.createUser(user);
    }
    
    private static void createProduct() {
        System.out.println("\n--- Create New Product ---");
        
        // First verify admin user
        System.out.print("Enter Admin User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        
        User adminUser = new User();
        adminUser.setUserId(userId);
        adminUser.setRole("Admin");
        
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter Product Name: ");
        String productName = scanner.nextLine();
        
        System.out.print("Enter Description: ");
        String description = scanner.nextLine();
        
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        
        System.out.print("Enter Quantity in Stock: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter Product Type (Electronics/Clothing): ");
        String type = scanner.nextLine();
        
        Product product;
        
        if ("Electronics".equalsIgnoreCase(type)) {
            System.out.print("Enter Brand: ");
            String brand = scanner.nextLine();
            
            System.out.print("Enter Warranty Period (months): ");
            int warranty = scanner.nextInt();
            scanner.nextLine();
            
            product = new Electronics(productId, productName, description, price, quantity, brand, warranty);
        } else if ("Clothing".equalsIgnoreCase(type)) {
            System.out.print("Enter Size: ");
            String size = scanner.nextLine();
            
            System.out.print("Enter Color: ");
            String color = scanner.nextLine();
            
            product = new Clothing(productId, productName, description, price, quantity, size, color);
        } else {
            product = new Product(productId, productName, description, price, quantity, type);
        }
        
        try {
            orderProcessor.createProduct(adminUser, product);
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private static void createOrder() {
        System.out.println("\n--- Create New Order ---");
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        
        User user = new User();
        user.setUserId(userId);
        
        List<Product> products = new ArrayList<>();
        boolean addingProducts = true;
        
        while (addingProducts) {
            System.out.print("Enter Product ID to add to order (or 0 to finish): ");
            int productId = scanner.nextInt();
            scanner.nextLine();
            
            if (productId == 0) {
                addingProducts = false;
            } else {
                Product product = new Product();
                product.setProductId(productId);
                products.add(product);
            }
        }
        
        try {
            orderProcessor.createOrder(user, products);
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private static void cancelOrder() {
        System.out.println("\n--- Cancel Order ---");
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter Order ID to cancel: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();
        
        try {
            orderProcessor.cancelOrder(userId, orderId);
        } catch (UserNotFoundException | OrderNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private static void getAllProducts() {
        System.out.println("\n--- All Products ---");
        List<Product> products = orderProcessor.getAllProducts();
        
        if (products.isEmpty()) {
            System.out.println("No products found.");
        } else {
            for (Product product : products) {
                System.out.println(product);
            }
        }
    }
    
    private static void getOrdersByUser() {
        System.out.println("\n--- Get Orders by User ---");
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        
        User user = new User();
        user.setUserId(userId);
        
        try {
            List<Product> products = orderProcessor.getOrderByUser(user);
            
            if (products.isEmpty()) {
                System.out.println("No orders found for this user.");
            } else {
                System.out.println("Products ordered by user " + userId + ":");
                for (Product product : products) {
                    System.out.println(product);
                }
            }
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
package dao;

import entity.*;
import exception.*;
import util.*;
import java.sql.*;
import java.util.*;

public class OrderProcessor implements IOrderManagementRepository {
    private Connection connection;

    public OrderProcessor() {
    	try {
            this.connection = DBConnUtil.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database connection", e);
        }
    
    }

    @Override
    public void createOrder(User user, List<Product> products) throws UserNotFoundException {
        try {
			if (!isUserExists(user.getUserId())) {
			    throw new UserNotFoundException("User with ID " + user.getUserId() + " not found.");
			}
		} catch (SQLException | UserNotFoundException e) {
			e.printStackTrace();
		}

        try {
            connection.setAutoCommit(false);
            
            // Create order
            String orderQuery = "INSERT INTO Orders (orderId, userId) VALUES (?, ?)";
            int orderId = generateOrderId();
            
            try (PreparedStatement orderStmt = connection.prepareStatement(orderQuery)) {
                orderStmt.setInt(1, orderId);
                orderStmt.setInt(2, user.getUserId());
                orderStmt.executeUpdate();
            }
            
            // Add order details
            String orderDetailQuery = "INSERT INTO OrderDetails (orderDetailId, orderId, productId, quantity) VALUES (?, ?, ?, ?)";
            int detailId = 1;
            
            for (Product product : products) {
                if (!isProductExists(product.getProductId())) {
                    throw new ProductNotFoundException("Product with ID " + product.getProductId() + " not found.");
                }
                
                try (PreparedStatement detailStmt = connection.prepareStatement(orderDetailQuery)) {
                    detailStmt.setInt(1, detailId++);
                    detailStmt.setInt(2, orderId);
                    detailStmt.setInt(3, product.getProductId());
                    detailStmt.setInt(4, 1); // Default quantity of 1
                    detailStmt.executeUpdate();
                }
                
                // Update product stock
                updateProductStock(product.getProductId(), -1);
            }
            
            connection.commit();
            System.out.println("Order created successfully with ID: " + orderId);
            
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } catch (ProductNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try {
			if (!isUserExists(userId)) {
			    throw new UserNotFoundException("User with ID " + userId + " not found.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        try {
			if (!isOrderExists(orderId)) {
			    throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OrderNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        try {
            connection.setAutoCommit(false);
            
            // Get products from order to restore stock
            String getProductsQuery = "SELECT productId FROM OrderDetails WHERE orderId = ?";
            List<Integer> productIds = new ArrayList<>();
            
            try (PreparedStatement stmt = connection.prepareStatement(getProductsQuery)) {
                stmt.setInt(1, orderId);
                ResultSet rs = stmt.executeQuery();
                
                while (rs.next()) {
                    productIds.add(rs.getInt("productId"));
                }
            }
            
            // Restore stock for each product
            for (int productId : productIds) {
                updateProductStock(productId, 1);
            }
            
            // Delete order details
            String deleteDetailsQuery = "DELETE FROM OrderDetails WHERE orderId = ?";
            try (PreparedStatement stmt = connection.prepareStatement(deleteDetailsQuery)) {
                stmt.setInt(1, orderId);
                stmt.executeUpdate();
            }
            
            // Delete order
            String deleteOrderQuery = "DELETE FROM Orders WHERE orderId = ?";
            try (PreparedStatement stmt = connection.prepareStatement(deleteOrderQuery)) {
                stmt.setInt(1, orderId);
                stmt.executeUpdate();
            }
            
            connection.commit();
            System.out.println("Order " + orderId + " cancelled successfully.");
            
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void createProduct(User user, Product product) throws UserNotFoundException {
        try {
			if (!isUserExists(user.getUserId())) {
			    throw new UserNotFoundException("User with ID " + user.getUserId() + " not found.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        if (!"Admin".equals(user.getRole())) {
            System.out.println("Only admin users can create products.");
            return;
        }
        
        String query = "INSERT INTO Products (productId, productName, description, price, quantityInStock, type";
        String values = "VALUES (?, ?, ?, ?, ?, ?";
        
        if (product instanceof Electronics) {
            query += ", brand, warrantyPeriod) ";
            values += ", ?, ?)";
        } else if (product instanceof Clothing) {
            query += ", size, color) ";
            values += ", ?, ?)";
        } else {
            query += ") ";
            values += ")";
        }
        
        try (PreparedStatement stmt = connection.prepareStatement(query + values)) {
            stmt.setInt(1, product.getProductId());
            stmt.setString(2, product.getProductName());
            stmt.setString(3, product.getDescription());
            stmt.setDouble(4, product.getPrice());
            stmt.setInt(5, product.getQuantityInStock());
            stmt.setString(6, product.getType());
            
            if (product instanceof Electronics) {
                Electronics electronics = (Electronics) product;
                stmt.setString(7, electronics.getBrand());
                stmt.setInt(8, electronics.getWarrantyPeriod());
            } else if (product instanceof Clothing) {
                Clothing clothing = (Clothing) product;
                stmt.setString(7, clothing.getSize());
                stmt.setString(8, clothing.getColor());
            }
            
            stmt.executeUpdate();
            System.out.println("Product created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createUser(User user) {
        String query = "INSERT INTO Users (userId, username, password, role) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, user.getUserId());
            stmt.setString(2, user.getUsername());
            stmt.setString(3, user.getPassword());
            stmt.setString(4, user.getRole());
            stmt.executeUpdate();
            System.out.println("User created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM Products";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Product product;
                String type = rs.getString("type");
                
                if ("Electronics".equals(type)) {
                    product = new Electronics(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        rs.getString("brand"),
                        rs.getInt("warrantyPeriod")
                    );
                } else if ("Clothing".equals(type)) {
                    product = new Clothing(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        rs.getString("size"),
                        rs.getString("color")
                    );
                } else {
                    product = new Product(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        type
                    );
                }
                
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return products;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
        try {
			if (!isUserExists(user.getUserId())) {
			    throw new UserNotFoundException("User with ID " + user.getUserId() + " not found.");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (UserNotFoundException e) {
			
			e.printStackTrace();
		}
        
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.* FROM Products p " +
                      "JOIN OrderDetails od ON p.productId = od.productId " +
                      "JOIN Orders o ON od.orderId = o.orderId " +
                      "WHERE o.userId = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, user.getUserId());
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Product product;
                String type = rs.getString("type");
                
                if ("Electronics".equals(type)) {
                    product = new Electronics(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        rs.getString("brand"),
                        rs.getInt("warrantyPeriod")
                    );
                } else if ("Clothing".equals(type)) {
                    product = new Clothing(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        rs.getString("size"),
                        rs.getString("color")
                    );
                } else {
                    product = new Product(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        type
                    );
                }
                
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return products;
    }

    // Helper methods
    private boolean isUserExists(int userId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Users WHERE userId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    private boolean isProductExists(int productId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Products WHERE productId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    private boolean isOrderExists(int orderId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Orders WHERE orderId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    private void updateProductStock(int productId, int quantityChange) throws SQLException {
        String query = "UPDATE Products SET quantityInStock = quantityInStock + ? WHERE productId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, quantityChange);
            stmt.setInt(2, productId);
            stmt.executeUpdate();
        }
    }

    private int generateOrderId() throws SQLException {
        String query = "SELECT MAX(orderId) FROM Orders";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1) + 1;
            }
            return 1;
        }
    }
}
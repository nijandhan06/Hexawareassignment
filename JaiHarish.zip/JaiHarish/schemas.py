from pydantic import BaseModel, validator
from datetime import datetime
from typing import Optional

class DoctorCreate(BaseModel):
    name: str
    specialization: Optional[str] = None
    license_number: str

class DoctorResponse(DoctorCreate):
    id: int
    created_at: datetime
    
    class Config:
        orm_mode = True

class PatientCreate(BaseModel):
    name: str
    age: int
    diagnosis: str
    admission_date: Optional[datetime] = None
    doctor_id: Optional[int] = None
    
    @validator('admission_date', pre=True)
    def parse_admission_date(cls, value):
        if value is None:
            return datetime.utcnow()
        return value

class PatientResponse(PatientCreate):
    id: int
    discharge_date: Optional[datetime] = None
    
    class Config:
        orm_mode = True
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from models import db, Doctor, Patient
from schemas import DoctorCreate, PatientCreate, PatientResponse
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Create tables
with app.app_context():
    db.create_all()

# Patient CRUD Endpoints
@app.route('/patients', methods=['POST'])
def create_patient():
    data = request.get_json()
    patient_data = PatientCreate(**data)
    
    patient = Patient(
        name=patient_data.name,
        age=patient_data.age,
        diagnosis=patient_data.diagnosis,
        admission_date=patient_data.admission_date,
        doctor_id=patient_data.doctor_id
    )
    
    db.session.add(patient)
    db.session.commit()
    
    return jsonify(PatientResponse.from_orm(patient).dict()), 201

@app.route('/patients', methods=['GET'])
def get_patients():
    patients = Patient.query.all()
    return jsonify([PatientResponse.from_orm(p).dict() for p in patients])

@app.route('/patients/<int:patient_id>', methods=['GET'])
def get_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    return jsonify(PatientResponse.from_orm(patient).dict())

@app.route('/patients/<int:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    data = request.get_json()
    patient_data = PatientCreate(**data)
    
    patient.name = patient_data.name
    patient.age = patient_data.age
    patient.diagnosis = patient_data.diagnosis
    patient.admission_date = patient_data.admission_date
    patient.doctor_id = patient_data.doctor_id
    
    db.session.commit()
    return jsonify(PatientResponse.from_orm(patient).dict())

@app.route('/patients/<int:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    db.session.delete(patient)
    db.session.commit()
    return jsonify({'message': 'Patient deleted successfully'}), 200

# Doctor-Patient Relationship Endpoints
@app.route('/doctors/<int:doctor_id>/patients', methods=['GET'])
def get_doctor_patients(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    patients = doctor.patients
    return jsonify([PatientResponse.from_orm(p).dict() for p in patients])

if __name__ == '__main__':
    app.run(debug=True, port=5000)